<?php
$idpelicula = $_GET['idpelicula'];
echo 'Su comentario se dio de alta en forma exitosa. Haga clic <a href="detallepelicula.php?idpelicula='.$idpelicula.'"> aqui </a> para volver a la pagina anterior.';

?>