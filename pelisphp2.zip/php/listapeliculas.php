
<?php

require_once("funciones.php");

listarpeliculas($conexion);


?>
