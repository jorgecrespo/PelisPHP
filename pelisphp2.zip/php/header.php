<div>
    <div>
<a href="../index.php"><img src="../img/logo1.png"></a>
</div><div><h1>Filmic!</h1></div></div>
